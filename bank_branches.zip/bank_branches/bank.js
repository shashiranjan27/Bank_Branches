var settings = {
    "async": true,
    "crossDomain": true,
    "url": "https://app.fyle.in/api/bank_branches?city=BANGALORE&offset=0&limit=50",
    "method": "GET"
}


function loadXMLDoc() {

    var city = document.getElementById('city').value.toUpperCase();
    var data = null;
    var xhr = new XMLHttpRequest();
    xhr.open("GET", "https://app.fyle.in/api/bank_branches?city=" + city + "&offset=0&limit=50");
    xhr.send(data);
    xhr.addEventListener("readystatechange", function () {
        if (this.readyState === 4) {
            console.log(this.responseText);
            myFunction(this.responseText);
        }
    });
}

function myFunction(xml) {
    console.log(xml)
    var data = JSON.parse(xml);
    var i;
    var template = document.getElementById('bankdata');
    var accordionList = document.getElementById('DisplayTable');
    accordionList.innerHTML = '';
    var templateHtml = template ? template.innerHTML : '';
    var listHtml = '';

    for (var i = 0; i < data.length; i++) {

        listHtml += templateHtml.replace(/{{ifsc}}/g, data[i].ifsc)
            .replace(/{{bank_id}}/g, data[i].bank_id)
            .replace(/{{bank_name}}/g, data[i].bank_name)
            .replace(/{{branch}}/g, data[i].branch)
            .replace(/{{address}}/g, data[i].address)
            .replace(/{{city}}/g, data[i].city)
            .replace(/{{district}}/g, data[i].district)
            .replace(/{{state}}/g, data[i].state);
    }
    accordionList.innerHTML += listHtml;
}

function SearchFunction() {
    var input, filter, table, tr, td, i;
    input = document.getElementById("SearchInput");
    filter = input.value.toUpperCase();
    table = document.getElementById("DisplayTable");
    tr = table.getElementsByTagName("tr");
    for (i = 0; i < tr.length; i++) {
        td = tr[i].getElementsByTagName("td")[3];
        if (td) {
            if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                tr[i].style.display = "";
            } else {
                tr[i].style.display = "none";
            }
        }
    }
}
